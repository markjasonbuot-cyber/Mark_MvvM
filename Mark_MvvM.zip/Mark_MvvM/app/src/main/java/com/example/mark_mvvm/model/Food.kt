package com.example.mark_mvvm.model
data class Food(
    val name: String,
    val price: String,
    val imageRes: Int
)
