package com.example.mark_mvvm.adapter

class FoodAdapter {
}